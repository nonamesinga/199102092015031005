<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>UjianDevel.com</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="/199102092015031005/public/vendors/feather/feather.css">
  <link rel="stylesheet" href="/199102092015031005/public/vendors/ti-icons/css/themify-icons.css">
  <link rel="stylesheet" href="/199102092015031005/public/vendors/css/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- Plugin css for this page -->
  <link rel="stylesheet" href="/199102092015031005/public/vendors/datatables.net-bs4/dataTables.bootstrap4.css">
  <link rel="stylesheet" href="/199102092015031005/public/vendors/ti-icons/css/themify-icons.css">
  <link rel="stylesheet" type="text/css" href="/199102092015031005/public/js/select.dataTables.min.css">
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="/199102092015031005/public/css/vertical-layout-light/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="/199102092015031005/public/images/logo-pt-tjk.ico" />
</head>
<body class="sidebar-light">
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row" >
      <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-centerr"  style="width:100%; justify-content: space-between!important;">
        <font class="navbar-brand brand-logo ml-5 mr-5" style="justify-content: center!important;" ><strong>UjianDevel.com</strong></font>
        <font class="navbar-brand brand-logo ml-5 mr-5"><span class="badge badge-light" ><strong>Anda login sebagai Eko Dwi Wibowo <br>Selamat datang NIP.199102092015031005</strong></span></font>
		
		<button class="navbar-brand navbar-toggler navbar-toggler-right d-lg-none align-self-center" >
		<font class="navbar-toggler navbar-toggler-right d-lg-none align-self-center"  data-toggle="offcanvas">
          <span class="icon-menu"></span>
        </font>
		<strong>&nbsp; UjianDevel.com</strong></button>
			
		
      </div>
    </nav>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">

      <!-- partial:partials/_sidebar.html -->
      
      <!-- partial -->
      <div class="main-panel" style="width: 100%;">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-md-12 grid-margin">
              <div class="row">
                <div class="col-12 col-xl-8 mb-4 mb-xl-0">
                  <h3 class="font-weight-bold">UjianDevel.com</h3>
                  <h6 class="font-weight-normal mb-0"><strong>Halaman ini menyajikan hasil ujian Peserta Programer Rekrutmen MA</strong></h6>
                </div>
                <div class="col-12 col-xl-4">
                 <div class="justify-content-end d-flex">
                  <div class="dropdown flex-md-grow-1 flex-xl-grow-0">
                    <button class="btn btn-sm btn-light bg-white">
                     <i class="mdi mdi-calendar"></i><strong>Tanggal  <span id="tahun"><?php echo $yy=date('d M Y'); ?></span></strong>
                    </button>
                  </div>
                 </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <div class="row">
                    <div class="col-12">
						<table id="example" class="display expandable-table" style="width:100%">
                          <thead>
                            <tr>
                              <th>#</th>
                              <th>Nama/NIP</th>
                              <th>Satuan Kerja</th>
                              <th>Posisi yang dilamar</th>
                              <th>Keahlian</th>
                              <th>Nilai</th>
                              <th></th>
                            </tr>
                          </thead>
						  </tbody>
							<?php 
							$File = "http://103.226.55.159/json/data_attribut.json";
							// Mendapatkan File Json
							$DataAPI = File_get_contents($File);
							// Mendecode Prov.Json
							$Data = Json_decode($DataAPI, True);
							 Foreach ($Data As $Row):
									$nilai[$Row['id_pendaftar']][$Row['jenis_attr']]=$Row['value'];
							 Endforeach ;
							
							$File = "http://103.226.55.159/json/data_rekrutmen.json";
							// Mendapatkan File Json
							$DataAPI = File_get_contents($File);
							// Mendecode Prov.Json
							$Data = Json_decode($DataAPI, True);
							
							 Foreach ($Data As $child): 
								Foreach ($child As $Row): 
							 ?>
										<Tr>
											<Td><?php echo @$No+=1 ?></Td>
											<Td><?php echo $Row["nama"] ?><br>NIP.<?php echo $Row["nip"] ?></Td>
											<Td><?php echo $Row["satuan_kerja"] ?></Td>
											<Td><?php echo $Row["posisi_yang_dipilih"] ?></Td>
											<Td><?php echo "<strong>Bahasa pemrograman:</strong><br>" . (!empty($Row["bahasa_pemrograman_yang_dikuasai"])?@$Row["bahasa_pemrograman_yang_dikuasai"]: "-") ?><br>
											<?php echo "<strong>Framework:</strong><br>" . (!empty($Row["framework_bahasa_pemrograman_yang_dikuasai"])?@$Row["framework_bahasa_pemrograman_yang_dikuasai"]: "-") ?><br>
											<?php echo "<strong>Database:</strong><br>" . (!empty($Row["database_yang_dikuasai"])?@$Row["database_yang_dikuasai"]: "-") ?><br>
											<?php echo "<strong>Tool:</strong><br>" . (!empty($Row["tools_yang_dikuasai"])?@$Row["tools_yang_dikuasai"]: "-") ?><br>
											<?php echo "<strong>Mobile Apps:</strong><br>" . (!empty($Row["pernah_membuat_mobile_apps"])?@$Row["pernah_membuat_mobile_apps"]: "-") ?><br></Td>
											<Td width="10%"><?php echo "<strong>Tes 1:</strong> " . (!empty($nilai[@$Row["id"]]['nilai_t1'])?@$nilai[@$Row["id"]]['nilai_t1']: "-") ?><br>
												<?php echo "<strong>Tes 2:</strong> " . (!empty($nilai[@$Row["id"]]['nilai_t2'])?@$nilai[@$Row["id"]]['nilai_t2']: "-") ?><br>
												<?php echo "<strong>Tes 3:</strong> " . (!empty($nilai[@$Row["id"]]['nilai_t3'])?@$nilai[@$Row["id"]]['nilai_t3']: "-") ?><br>
												<?php echo "<strong>Url File:</strong> <a href='" . (!empty($nilai[@$Row["id"]]['url_file'])?@$nilai[@$Row["id"]]['url_file']: "-") . "'> unduh </a>" ?><br></Td>
										</Tr>
									<?Php Endforeach ;
							 Endforeach ;?>	
						  </tbody>
						</table>
                    </div>
                  </div>
                  </div>
                </div>
              </div>
            </div>
		</div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <footer class="footer">
          <div class="d-sm-flex justify-content-center justify-content-sm-between">
            <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2023.  Eko Dwi Wibowo / NIP.199102092015031005.</span>
            <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Pengadilan Tinggi Tanjungkarang <i class="ti-heart text-danger ml-1"></i></span>
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

  <!-- plugins:js -->
  <script src="/199102092015031005/public/vendors/js/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page -->
  <script src="/199102092015031005/public/vendors/chart.js/Chart.min.js"></script>
  <script src="/199102092015031005/public/vendors/datatables.net/jquery.dataTables.js"></script>
  <script src="/199102092015031005/public/vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>
  <script src="/199102092015031005/public/js/dataTables.select.min.js"></script>

  <!-- End plugin js for this page -->
  <!-- inject:js -->
  <script src="/199102092015031005/public/js/off-canvas.js"></script>
  <script src="/199102092015031005/public/js/hoverable-collapse.js"></script>
  <script src="/199102092015031005/public/js/template.js"></script>
  <script src="/199102092015031005/public/js/settings.js"></script>
  <script src="/199102092015031005/public/js/todolist.js"></script>
	
  <script>
	$('#example').DataTable( {
		"processing": true,
		"paging":   false,
		"ordering": false,
		"info":     false,
		"filter": false
		
	  } );
  </script>
</body>

</html>

